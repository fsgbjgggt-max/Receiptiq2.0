package com.receiptiq.app

import io.flutter.embedding.android.FlutterFragmentActivity

// FlutterFragmentActivity is required for local_auth biometric support
class MainActivity : FlutterFragmentActivity()
