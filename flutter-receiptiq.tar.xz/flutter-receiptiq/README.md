# ReceiptIQ — Flutter

Privacy-first AI receipt scanner and personal finance tracker. All data stays on-device.

## Features

- **Receipt scanning** — Google ML Kit on-device OCR (no cloud)
- **Dashboard** — spending ring chart, budget overview, recent transactions
- **Transactions** — grouped list, search, category filters
- **Analytics** — 6-month trend chart, category breakdown, subscription tracker
- **Budgets** — per-category limits with progress bars
- **AI Assistant** — rule-based chat that reads your local data
- **Biometrics** — Face ID / Fingerprint lock
- **Settings** — currency, privacy mode, export

## Setup (required before building)

This archive contains only the **custom code** (lib/, pubspec.yaml, android config).
You must run `flutter create` once to generate the missing scaffold files:

```bash
# 1. Create scaffold
flutter create --org com.receiptiq receiptiq
cd receiptiq

# 2. Copy lib/ from this archive into the project
cp -r /path/to/archive/lib ./

# 3. Replace pubspec.yaml
cp /path/to/archive/pubspec.yaml ./

# 4. Merge android changes
#    - Copy android/app/build.gradle (sets minSdk 21, namespace)
#    - Copy android/app/src/main/AndroidManifest.xml (permissions)
#    - Copy android/app/src/main/kotlin/com/receiptiq/app/MainActivity.kt
#    - Copy android/app/proguard-rules.pro

# 5. Install packages and build
flutter pub get
flutter build apk --release
```

APK will be at: `build/app/outputs/flutter-apk/app-release.apk`

## GitHub Actions (auto-build on push)

The `.github/workflows/build-apk.yml` workflow automatically builds the APK
on every push to main/master.

After it runs, go to:
**GitHub repo → Actions tab → latest run → Artifacts → receiptiq-release-apk**

Download and install the APK directly on your Android phone.

No EAS account, no Expo account, no store submission required.

## Tech stack

- Flutter 3.24 / Dart 3.3
- Provider (state management)
- SharedPreferences (local storage)
- google_mlkit_text_recognition (on-device OCR)
- local_auth (biometrics)
- fl_chart (charts)
- image_picker (camera/gallery)

## Theme

| Token | Color |
|-------|-------|
| Background | `#09090F` |
| Card | `#131320` |
| Primary | `#6366F1` (indigo) |
| Accent | `#8B5CF6` (violet) |
| Success | `#10B981` |
| Destructive | `#F43F5E` |
