import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/transaction.dart';
import '../models/budget.dart';

const _uuid = Uuid();

const _sampleTransactions = [
  {'merchant': 'Whole Foods Market', 'category': 'food', 'amount': -67.42, 'date': '2026-06-20', 'note': 'Weekly groceries', 'isSubscription': false},
  {'merchant': 'Netflix', 'category': 'subscriptions', 'amount': -15.99, 'date': '2026-06-19', 'note': '', 'isSubscription': true},
  {'merchant': 'Shell Gas Station', 'category': 'transport', 'amount': -48.30, 'date': '2026-06-19', 'note': '', 'isSubscription': false},
  {'merchant': 'Salary Deposit', 'category': 'other', 'amount': 3500.00, 'date': '2026-06-18', 'note': 'June paycheck', 'isSubscription': false},
  {'merchant': 'Starbucks', 'category': 'food', 'amount': -6.75, 'date': '2026-06-18', 'note': '', 'isSubscription': false},
  {'merchant': 'Uber', 'category': 'transport', 'amount': -12.40, 'date': '2026-06-17', 'note': '', 'isSubscription': false},
  {'merchant': 'Spotify', 'category': 'subscriptions', 'amount': -9.99, 'date': '2026-06-17', 'note': '', 'isSubscription': true},
  {'merchant': 'CVS Pharmacy', 'category': 'health', 'amount': -23.15, 'date': '2026-06-16', 'note': '', 'isSubscription': false},
  {'merchant': 'Target', 'category': 'shopping', 'amount': -84.20, 'date': '2026-06-15', 'note': 'Household items', 'isSubscription': false},
  {'merchant': 'Planet Fitness', 'category': 'health', 'amount': -24.99, 'date': '2026-06-14', 'note': '', 'isSubscription': true},
  {'merchant': 'Amazon', 'category': 'shopping', 'amount': -39.99, 'date': '2026-06-13', 'note': '', 'isSubscription': false},
  {'merchant': 'Chipotle', 'category': 'food', 'amount': -13.50, 'date': '2026-06-12', 'note': '', 'isSubscription': false},
  {'merchant': 'AT&T', 'category': 'utilities', 'amount': -65.00, 'date': '2026-06-11', 'note': 'Monthly phone bill', 'isSubscription': true},
  {'merchant': 'Home Depot', 'category': 'shopping', 'amount': -127.45, 'date': '2026-06-10', 'note': '', 'isSubscription': false},
  {'merchant': 'Freelance Income', 'category': 'other', 'amount': 850.00, 'date': '2026-06-09', 'note': '', 'isSubscription': false},
];

class AppProvider extends ChangeNotifier {
  List<Transaction> _transactions = [];
  List<Budget> _budgets = [];
  String _userName = '';
  String _currency = 'USD';
  bool _biometricEnabled = false;
  bool _privacyMode = false;
  bool _onboardingDone = false;

  List<Transaction> get transactions => _transactions;
  List<Budget> get budgets => _budgets;
  String get userName => _userName;
  String get currency => _currency;
  bool get biometricEnabled => _biometricEnabled;
  bool get privacyMode => _privacyMode;
  bool get onboardingDone => _onboardingDone;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _onboardingDone = prefs.getBool('onboardingDone') ?? false;
    _userName = prefs.getString('userName') ?? '';
    _currency = prefs.getString('currency') ?? 'USD';
    _biometricEnabled = prefs.getBool('biometricEnabled') ?? false;
    _privacyMode = prefs.getBool('privacyMode') ?? false;

    final txJson = prefs.getString('transactions');
    if (txJson != null) {
      final list = jsonDecode(txJson) as List;
      _transactions = list.map((e) => Transaction.fromJson(e as Map<String, dynamic>)).toList();
    } else {
      _seedSampleData();
      await _saveTransactions(prefs);
    }

    final budgetJson = prefs.getString('budgets');
    if (budgetJson != null) {
      final list = jsonDecode(budgetJson) as List;
      _budgets = list.map((e) => Budget.fromJson(e as Map<String, dynamic>)).toList();
    } else {
      _budgets = [
        Budget(id: _uuid.v4(), category: 'food', limit: 500),
        Budget(id: _uuid.v4(), category: 'transport', limit: 200),
        Budget(id: _uuid.v4(), category: 'shopping', limit: 300),
      ];
      await _saveBudgets(prefs);
    }
    notifyListeners();
  }

  void _seedSampleData() {
    _transactions = _sampleTransactions.map((d) {
      return Transaction(
        id: _uuid.v4(),
        merchant: d['merchant'] as String,
        category: d['category'] as String,
        amount: d['amount'] as double,
        date: d['date'] as String,
        note: d['note'] as String,
        isSubscription: d['isSubscription'] as bool,
      );
    }).toList();
  }

  Future<void> completeOnboarding(String name) async {
    _userName = name;
    _onboardingDone = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboardingDone', true);
    await prefs.setString('userName', name);
    notifyListeners();
  }

  Future<void> addTransaction(Transaction tx) async {
    _transactions.insert(0, tx);
    final prefs = await SharedPreferences.getInstance();
    await _saveTransactions(prefs);
    notifyListeners();
  }

  Future<void> updateTransaction(Transaction tx) async {
    final idx = _transactions.indexWhere((t) => t.id == tx.id);
    if (idx >= 0) {
      _transactions[idx] = tx;
      final prefs = await SharedPreferences.getInstance();
      await _saveTransactions(prefs);
      notifyListeners();
    }
  }

  Future<void> deleteTransaction(String id) async {
    _transactions.removeWhere((t) => t.id == id);
    final prefs = await SharedPreferences.getInstance();
    await _saveTransactions(prefs);
    notifyListeners();
  }

  Future<void> addBudget(Budget b) async {
    _budgets.add(b);
    final prefs = await SharedPreferences.getInstance();
    await _saveBudgets(prefs);
    notifyListeners();
  }

  Future<void> deleteBudget(String id) async {
    _budgets.removeWhere((b) => b.id == id);
    final prefs = await SharedPreferences.getInstance();
    await _saveBudgets(prefs);
    notifyListeners();
  }

  Future<void> updateSettings({
    String? userName,
    String? currency,
    bool? biometricEnabled,
    bool? privacyMode,
  }) async {
    if (userName != null) _userName = userName;
    if (currency != null) _currency = currency;
    if (biometricEnabled != null) _biometricEnabled = biometricEnabled;
    if (privacyMode != null) _privacyMode = privacyMode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('userName', _userName);
    await prefs.setString('currency', _currency);
    await prefs.setBool('biometricEnabled', _biometricEnabled);
    await prefs.setBool('privacyMode', _privacyMode);
    notifyListeners();
  }



    // PASTE THIS NEW FIXED CODE BLOCK:

  // 1. CLEAR SAMPLE DATA ENGINE FIX
  /// Explicitly clears all transaction records and stops mock fallbacks.
  Future<void> clearAllData() async {
    _transactions = [];
    final prefs = await SharedPreferences.getInstance();
    // Save an empty list string so txJson is recognized but contains nothing
    await prefs.setString('transactions', jsonEncode([]));
    notifyListeners();
  }

  // 2. CURRENCY SWITCHING & CONVERSION PIPELINE
  // Hardcoded mock currency exchange table (Base reference: USD)
  final Map<String, double> _exchangeRates = {
    'USD': 1.0,
    'INR': 83.50, // Added explicit Indian Rupee conversion scale factor
    'EUR': 0.92,
  };

  /// Converts a transaction value to the app's globally chosen currency
  double _convertToSelectedCurrency(double amount) {
    // This app stores raw underlying numbers natively in USD currency
    final double rate = _exchangeRates[_currency] ?? 1.0;
    return amount * rate;
  }

  // 3. RUPEES TEXT FORMATTING UTILITY
  /// Formats raw numeric values into standard global currency symbols
  String formatCurrencyValue(double amount) {
    if (_currency == 'INR') {
      // Formats currency string values according to standard Indian localized syntax
      return '₹${amount.toStringAsFixed(2)}';
    } else if (_currency == 'EUR') {
      return '€${amount.toStringAsFixed(2)}';
    } else {
      return '\$${amount.toStringAsFixed(2)}';
    }
  }

  // ---- Fixed Computed Helpers ----

  String get currentMonth {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}';
  }

  List<Transaction> get monthTransactions =>
      _transactions.where((t) => t.date.startsWith(currentMonth)).toList();

  double get monthSpent => monthTransactions
      .where((t) => t.amount < 0)
      .fold(0.0, (s, t) => s + _convertToSelectedCurrency(t.amount.abs()));

  double get monthIncome => monthTransactions
      .where((t) => t.amount > 0)
      .fold(0.0, (s, t) => s + _convertToSelectedCurrency(t.amount));

  double get monthSubscriptions => monthTransactions
      .where((t) => t.isSubscription)
      .fold(0.0, (s, t) => s + _convertToSelectedCurrency(t.amount.abs()));

  Map<String, double> get spendingByCategory {
    final map = <String, double>{};
    for (final tx in monthTransactions.where((t) => t.amount < 0)) {
      final convertedAmount = _convertToSelectedCurrency(tx.amount.abs());
      map[tx.category] = (map[tx.category] ?? 0) + convertedAmount;
    }
    return map;
  }

  double budgetSpent(String category) => monthTransactions
      .where((t) => t.category == category && t.amount < 0)
      .fold(0.0, (s, t) => s + _convertToSelectedCurrency(t.amount.abs()));

  Future<void> _saveTransactions(SharedPreferences prefs) async {
    await prefs.setString('transactions', jsonEncode(_transactions.map((t) => t.toJson()).toList()));
  }

  Future<void> _saveBudgets(SharedPreferences prefs) async {
    await prefs.setString('budgets', jsonEncode(_budgets.map((b) => b.toJson()).toList()));
  }
}

