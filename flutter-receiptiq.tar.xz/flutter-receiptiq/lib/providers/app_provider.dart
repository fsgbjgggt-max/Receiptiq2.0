import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/budget.dart';
import '../models/transaction.dart';

class AppProvider extends ChangeNotifier {
  static const Uuid _uuid = Uuid();

  static const List<String> supportedCurrencies = [
    'INR',
    'USD',
    'EUR',
    'GBP',
    'JPY',
    'CAD',
    'AUD',
  ];

  static const Map<String, String> _currencySymbols = {
    'INR': '₹',
    'USD': '\$',
    'EUR': '€',
    'GBP': '£',
    'JPY': '¥',
    'CAD': 'C\$',
    'AUD': 'A\$',
  };

  List<Transaction> _transactions = [];
  List<Budget> _budgets = [];
  String _userName = '';
  String _currency = 'INR';
  bool _biometricEnabled = false;
  bool _privacyMode = false;
  bool _onboardingDone = false;

  List<Transaction> get transactions => _transactions;
  List<Budget> get budgets => _budgets;
  String get userName => _userName;
  String get currency => _currency;
  bool get biometricEnabled => _biometricEnabled;
  bool get privacyMode => _privacyMode;
  bool get onboardingDone => _onboardingDone;

  String get currencySymbol => _currencySymbols[_currency] ?? '₹';

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();

    _onboardingDone = prefs.getBool('onboardingDone') ?? false;
    _userName = prefs.getString('userName') ?? '';
    _currency = prefs.getString('currency') ?? 'INR';
    _biometricEnabled = prefs.getBool('biometricEnabled') ?? false;
    _privacyMode = prefs.getBool('privacyMode') ?? false;

    final txJson = prefs.getString('transactions');
    if (txJson != null && txJson.isNotEmpty) {
      final list = jsonDecode(txJson) as List;
      _transactions = list
          .map((e) => Transaction.fromJson(e as Map<String, dynamic>))
          .toList();
    } else {
      _transactions = [];
      await _saveTransactions(prefs);
    }

    final budgetJson = prefs.getString('budgets');
    if (budgetJson != null && budgetJson.isNotEmpty) {
      final list = jsonDecode(budgetJson) as List;
      _budgets =
          list.map((e) => Budget.fromJson(e as Map<String, dynamic>)).toList();
    } else {
      _budgets = [];
      await _saveBudgets(prefs);
    }

    notifyListeners();
  }

  Future<void> completeOnboarding(String name) async {
    _userName = name;
    _onboardingDone = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboardingDone', true);
    await prefs.setString('userName', name);
    notifyListeners();
  }

  Future<void> addTransaction(Transaction tx) async {
    _transactions.insert(0, tx);
    final prefs = await SharedPreferences.getInstance();
    await _saveTransactions(prefs);
    notifyListeners();
  }

  Future<void> updateTransaction(Transaction tx) async {
    final idx = _transactions.indexWhere((t) => t.id == tx.id);
    if (idx >= 0) {
      _transactions[idx] = tx;
      final prefs = await SharedPreferences.getInstance();
      await _saveTransactions(prefs);
      notifyListeners();
    }
  }

  Future<void> deleteTransaction(String id) async {
    _transactions.removeWhere((t) => t.id == id);
    final prefs = await SharedPreferences.getInstance();
    await _saveTransactions(prefs);
    notifyListeners();
  }

  Future<void> addBudget(Budget b) async {
    _budgets.add(b);
    final prefs = await SharedPreferences.getInstance();
    await _saveBudgets(prefs);
    notifyListeners();
  }

  Future<void> deleteBudget(String id) async {
    _budgets.removeWhere((b) => b.id == id);
    final prefs = await SharedPreferences.getInstance();
    await _saveBudgets(prefs);
    notifyListeners();
  }

  Future<void> updateSettings({
    String? userName,
    String? currency,
    bool? biometricEnabled,
    bool? privacyMode,
  }) async {
    if (userName != null) _userName = userName;
    if (currency != null) _currency = currency;
    if (biometricEnabled != null) _biometricEnabled = biometricEnabled;
    if (privacyMode != null) _privacyMode = privacyMode;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('userName', _userName);
    await prefs.setString('currency', _currency);
    await prefs.setBool('biometricEnabled', _biometricEnabled);
    await prefs.setBool('privacyMode', _privacyMode);
    notifyListeners();
  }

  Future<void> clearAllData() async {
    _transactions = [];
    _budgets = [];
    final prefs = await SharedPreferences.getInstance();
    await _saveTransactions(prefs);
    await _saveBudgets(prefs);
    notifyListeners();
  }

  String formatMoney(
    double amount, {
    bool signed = false,
    int fractionDigits = 2,
  }) {
    final sign = signed
        ? (amount < 0 ? '-' : '+')
        : '';
    final value = amount.abs().toStringAsFixed(fractionDigits);
    return '$sign$currencySymbol$value';
  }

  String get currentMonth {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}';
  }

  List<Transaction> get monthTransactions =>
      _transactions.where((t) => t.date.startsWith(currentMonth)).toList();

  double get monthSpent => monthTransactions
      .where((t) => t.amount < 0)
      .fold(0.0, (s, t) => s + t.amount.abs());

  double get monthIncome => monthTransactions
      .where((t) => t.amount > 0)
      .fold(0.0, (s, t) => s + t.amount);

  double get monthSubscriptions => monthTransactions
      .where((t) => t.isSubscription)
      .fold(0.0, (s, t) => s + t.amount.abs());

  Map<String, double> get spendingByCategory {
    final map = <String, double>{};
    for (final tx in monthTransactions.where((t) => t.amount < 0)) {
      map[tx.category] = (map[tx.category] ?? 0) + tx.amount.abs();
    }
    return map;
  }

  double budgetSpent(String category) => monthTransactions
      .where((t) => t.category == category && t.amount < 0)
      .fold(0.0, (s, t) => s + t.amount.abs());

  Future<void> _saveTransactions(SharedPreferences prefs) async {
    await prefs.setString(
      'transactions',
      jsonEncode(_transactions.map((t) => t.toJson()).toList()),
    );
  }

  Future<void> _saveBudgets(SharedPreferences prefs) async {
    await prefs.setString(
      'budgets',
      jsonEncode(_budgets.map((b) => b.toJson()).toList()),
    );
  }
}