import 'package:flutter/material.dart';
import '../models/transaction.dart';
import '../theme.dart';
import '../widgets/spending_ring.dart';

const _catIcons = <String, IconData>{
  'food': Icons.restaurant_rounded,
  'transport': Icons.directions_car_rounded,
  'shopping': Icons.shopping_bag_rounded,
  'health': Icons.favorite_rounded,
  'subscriptions': Icons.subscriptions_rounded,
  'travel': Icons.flight_rounded,
  'utilities': Icons.bolt_rounded,
  'education': Icons.school_rounded,
  'entertainment': Icons.sports_esports_rounded,
  'other': Icons.category_rounded,
};

IconData categoryIcon(String cat) => _catIcons[cat] ?? Icons.category_rounded;

const _catLabels = <String, String>{
  'food': 'Food & Drink',
  'transport': 'Transport',
  'shopping': 'Shopping',
  'health': 'Health',
  'subscriptions': 'Subscriptions',
  'travel': 'Travel',
  'utilities': 'Utilities',
  'education': 'Education',
  'entertainment': 'Entertainment',
  'other': 'Other',
};

String categoryLabel(String cat) => _catLabels[cat] ?? 'Other';

class TransactionTile extends StatelessWidget {
  final Transaction transaction;
  final VoidCallback? onTap;

  const TransactionTile({super.key, required this.transaction, this.onTap});

  @override
  Widget build(BuildContext context) {
    final color = categoryColor(transaction.category);
    final isExpense = transaction.amount < 0;
    final amountStr = '${isExpense ? '-' : '+'}\$${transaction.amount.abs().toStringAsFixed(2)}';

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(categoryIcon(transaction.category), color: color, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    transaction.merchant,
                    style: const TextStyle(
                      color: AppColors.foreground,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Text(
                        categoryLabel(transaction.category),
                        style: const TextStyle(color: AppColors.mutedForeground, fontSize: 12),
                      ),
                      if (transaction.isSubscription) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                          decoration: BoxDecoration(
                            color: AppColors.accent.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text(
                            'Sub',
                            style: TextStyle(color: AppColors.accent, fontSize: 10, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                      if (transaction.receiptScanned) ...[
                        const SizedBox(width: 6),
                        Icon(Icons.receipt_rounded, size: 11, color: AppColors.success.withOpacity(0.7)),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            Text(
              amountStr,
              style: TextStyle(
                color: isExpense ? AppColors.foreground : AppColors.success,
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
