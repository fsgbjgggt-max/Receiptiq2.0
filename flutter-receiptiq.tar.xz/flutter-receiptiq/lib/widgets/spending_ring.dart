import 'dart:math';
import 'package:flutter/material.dart';
import '../theme.dart';

class SpendingRing extends StatelessWidget {
  final Map<String, double> data;
  final double size;
  final double strokeWidth;

  const SpendingRing({
    super.key,
    required this.data,
    this.size = 160,
    this.strokeWidth = 18,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _RingPainter(data: data, strokeWidth: strokeWidth),
      ),
    );
  }
}

const _catColors = <String, Color>{
  'food': Color(0xFF10B981),
  'transport': Color(0xFF3B82F6),
  'shopping': Color(0xFFEC4899),
  'health': Color(0xFFF43F5E),
  'subscriptions': Color(0xFF8B5CF6),
  'travel': Color(0xFF06B6D4),
  'utilities': Color(0xFFF59E0B),
  'education': Color(0xFFF97316),
  'entertainment': Color(0xFF6366F1),
  'other': Color(0xFF6B7280),
};

Color categoryColor(String cat) => _catColors[cat] ?? const Color(0xFF6B7280);

class _RingPainter extends CustomPainter {
  final Map<String, double> data;
  final double strokeWidth;

  _RingPainter({required this.data, required this.strokeWidth});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (min(size.width, size.height) / 2) - strokeWidth / 2;

    // Background track
    final trackPaint = Paint()
      ..color = AppColors.muted
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;
    canvas.drawCircle(center, radius, trackPaint);

    final total = data.values.fold(0.0, (s, v) => s + v);
    if (total == 0) return;

    double startAngle = -pi / 2;
    const gap = 0.04;

    for (final entry in data.entries) {
      final sweep = (entry.value / total) * (2 * pi - gap * data.length);
      final paint = Paint()
        ..color = categoryColor(entry.key)
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..strokeCap = StrokeCap.round;

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweep,
        false,
        paint,
      );
      startAngle += sweep + gap;
    }
  }

  @override
  bool shouldRepaint(_RingPainter old) => old.data != data;
}
