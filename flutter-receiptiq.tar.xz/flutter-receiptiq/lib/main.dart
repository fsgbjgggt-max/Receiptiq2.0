import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'providers/app_provider.dart';
import 'screens/onboarding_screen.dart';
import 'screens/home_screen.dart';
import 'theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarBrightness: Brightness.dark,
    statusBarIconBrightness: Brightness.light,
  ));

  final provider = AppProvider();
  await provider.init();

  runApp(
    ChangeNotifierProvider.value(
      value: provider,
      child: const ReceiptIQApp(),
    ),
  );
}

class ReceiptIQApp extends StatelessWidget {
  const ReceiptIQApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ReceiptIQ',
      theme: buildAppTheme(),
      debugShowCheckedModeBanner: false,
      home: Consumer<AppProvider>(
        builder: (_, app, __) =>
            app.onboardingDone ? const HomeScreen() : const OnboardingScreen(),
      ),
    );
  }
}
