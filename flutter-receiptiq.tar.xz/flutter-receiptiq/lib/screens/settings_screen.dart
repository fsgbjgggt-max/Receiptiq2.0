import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _auth = LocalAuthentication();
  bool _biometricAvailable = false;

  @override
  void initState() {
    super.initState();
    _checkBiometrics();
  }

  Future<void> _checkBiometrics() async {
    try {
      final available = await _auth.canCheckBiometrics;
      setState(() => _biometricAvailable = available);
    } catch (_) {}
  }

  void _editName(AppProvider app) {
    final ctrl = TextEditingController(text: app.userName);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Edit Name', style: TextStyle(fontWeight: FontWeight.w800)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: 'Your name'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              app.updateSettings(userName: ctrl.text.trim());
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.w800))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Profile card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.primary.withOpacity(0.15), AppColors.accent.withOpacity(0.1)],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.primary.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Container(
                  width: 56, height: 56,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [AppColors.primary, AppColors.accent]),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Center(
                    child: Text(
                      app.userName.isNotEmpty ? app.userName[0].toUpperCase() : '?',
                      style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(app.userName, style: const TextStyle(color: AppColors.foreground, fontSize: 18, fontWeight: FontWeight.w800)),
                      Text('${app.transactions.length} transactions', style: const TextStyle(color: AppColors.mutedForeground, fontSize: 13)),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.edit_rounded, color: AppColors.primary),
                  onPressed: () => _editName(app),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          _SectionHeader('Preferences'),
          _SettingsCard(children: [
            _DropdownTile(
              icon: Icons.attach_money_rounded,
              title: 'Currency',
              value: app.currency,
              items: const ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD'],
              onChanged: (v) => app.updateSettings(currency: v),
            ),
          ]),
          const SizedBox(height: 16),

          _SectionHeader('Security'),
          _SettingsCard(children: [
            if (_biometricAvailable)
              _SwitchTile(
                icon: Icons.fingerprint_rounded,
                title: 'Biometric Lock',
                subtitle: 'Face ID / Fingerprint',
                value: app.biometricEnabled,
                onChanged: (v) => app.updateSettings(biometricEnabled: v),
              ),
            if (_biometricAvailable) const Divider(indent: 56),
            _SwitchTile(
              icon: Icons.visibility_off_rounded,
              title: 'Privacy Mode',
              subtitle: 'Hide amounts in the app',
              value: app.privacyMode,
              onChanged: (v) => app.updateSettings(privacyMode: v),
            ),
          ]),
          const SizedBox(height: 16),

          _SectionHeader('Data'),
          _SettingsCard(children: [
            _ActionTile(
              icon: Icons.file_download_rounded,
              iconColor: AppColors.primary,
              title: 'Export Transactions',
              subtitle: 'CSV format',
              onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Export feature coming soon')),
              ),
            ),
            const Divider(indent: 56),
            _ActionTile(
              icon: Icons.delete_forever_rounded,
              iconColor: AppColors.destructive,
              title: 'Clear All Data',
              subtitle: 'This cannot be undone',
              textColor: AppColors.destructive,
              onTap: () => showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Clear All Data?'),
                  content: const Text('This will permanently delete all your transactions and budgets.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.destructive),
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Clear'),
                    ),
                  ],
                ),
              ),
            ),
          ]),
          const SizedBox(height: 24),

          // Privacy note
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.success.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.success.withOpacity(0.3)),
            ),
            child: Row(
              children: const [
                Icon(Icons.shield_rounded, color: AppColors.success, size: 20),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'All your data is stored locally on this device. Nothing is sent to any server.',
                    style: TextStyle(color: AppColors.success, fontSize: 13, height: 1.4),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),
          const Center(child: Text('ReceiptIQ v1.0.0', style: TextStyle(color: AppColors.mutedForeground, fontSize: 12))),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8, left: 4),
        child: Text(title, style: const TextStyle(color: AppColors.mutedForeground, fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 0.5)),
      );
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;
  const _SettingsCard({required this.children});
  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(children: children),
      );
}

class _SwitchTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _SwitchTile({required this.icon, required this.title, this.subtitle, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => SwitchListTile(
        secondary: Icon(icon, color: AppColors.primary, size: 20),
        title: Text(title, style: const TextStyle(color: AppColors.foreground, fontSize: 15, fontWeight: FontWeight.w600)),
        subtitle: subtitle != null ? Text(subtitle!, style: const TextStyle(color: AppColors.mutedForeground, fontSize: 12)) : null,
        value: value,
        onChanged: onChanged,
        activeColor: AppColors.primary,
      );
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String? subtitle;
  final Color? textColor;
  final VoidCallback onTap;
  const _ActionTile({required this.icon, required this.iconColor, required this.title, this.subtitle, this.textColor, required this.onTap});

  @override
  Widget build(BuildContext context) => ListTile(
        leading: Icon(icon, color: iconColor, size: 20),
        title: Text(title, style: TextStyle(color: textColor ?? AppColors.foreground, fontSize: 15, fontWeight: FontWeight.w600)),
        subtitle: subtitle != null ? Text(subtitle!, style: const TextStyle(color: AppColors.mutedForeground, fontSize: 12)) : null,
        trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.mutedForeground, size: 18),
        onTap: onTap,
      );
}

class _DropdownTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final List<String> items;
  final ValueChanged<String?> onChanged;
  const _DropdownTile({required this.icon, required this.title, required this.value, required this.items, required this.onChanged});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: Row(
          children: [
            Icon(icon, color: AppColors.primary, size: 20),
            const SizedBox(width: 16),
            Expanded(child: Text(title, style: const TextStyle(color: AppColors.foreground, fontSize: 15, fontWeight: FontWeight.w600))),
            DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: value,
                items: items.map((i) => DropdownMenuItem(value: i, child: Text(i, style: const TextStyle(color: AppColors.foreground)))).toList(),
                onChanged: onChanged,
                dropdownColor: AppColors.card,
                style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      );
}
