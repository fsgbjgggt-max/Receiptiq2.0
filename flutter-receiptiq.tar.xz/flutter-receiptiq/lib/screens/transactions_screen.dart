import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/transaction.dart';
import '../providers/app_provider.dart';
import '../theme.dart';
import '../widgets/transaction_tile.dart';
import 'transaction_detail_screen.dart';

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key});

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  String _query = '';
  String? _filterCat;
  bool _showIncome = false;

  static const _cats = ['food', 'transport', 'shopping', 'health', 'subscriptions', 'other'];

  List<Transaction> _filtered(List<Transaction> all) {
    return all.where((t) {
      final matchQ = _query.isEmpty || t.merchant.toLowerCase().contains(_query.toLowerCase());
      final matchCat = _filterCat == null || t.category == _filterCat;
      final matchType = _showIncome ? t.amount > 0 : t.amount < 0;
      return matchQ && matchCat && matchType;
    }).toList();
  }

  Map<String, List<Transaction>> _group(List<Transaction> txs) {
    final map = <String, List<Transaction>>{};
    for (final tx in txs) {
      (map[tx.date] ??= []).add(tx);
    }
    return map;
  }

  String _fmtDate(String d) {
    try {
      final dt = DateTime.parse(d);
      final today = DateTime.now();
      if (dt.year == today.year && dt.month == today.month && dt.day == today.day) return 'Today';
      final yest = today.subtract(const Duration(days: 1));
      if (dt.year == yest.year && dt.month == yest.month && dt.day == yest.day) return 'Yesterday';
      return DateFormat('MMMM d, yyyy').format(dt);
    } catch (_) {
      return d;
    }
  }

  @override
  Widget build(BuildContext context) {
    final all = context.watch<AppProvider>().transactions;
    final filtered = _filtered(all);
    final grouped = _group(filtered);
    final sortedDates = grouped.keys.toList()..sort((a, b) => b.compareTo(a));

    final totalFiltered = filtered.fold(0.0, (s, t) => s + t.amount);

    return Scaffold(
      appBar: AppBar(title: const Text('Transactions', style: TextStyle(fontWeight: FontWeight.w800))),
      body: Column(
        children: [
          // Search
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: TextField(
              onChanged: (v) => setState(() => _query = v),
              style: const TextStyle(color: AppColors.foreground),
              decoration: const InputDecoration(
                hintText: 'Search transactions…',
                prefixIcon: Icon(Icons.search_rounded, color: AppColors.mutedForeground),
              ),
            ),
          ),

          // Filter chips
          SizedBox(
            height: 50,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              children: [
                _FilterChip(
                  label: _showIncome ? 'Income' : 'Expenses',
                  icon: _showIncome ? Icons.arrow_downward : Icons.arrow_upward,
                  active: true,
                  color: _showIncome ? AppColors.success : AppColors.destructive,
                  onTap: () => setState(() => _showIncome = !_showIncome),
                ),
                const SizedBox(width: 6),
                _FilterChip(
                  label: 'All',
                  active: _filterCat == null,
                  onTap: () => setState(() => _filterCat = null),
                ),
                ..._cats.map((c) => Padding(
                      padding: const EdgeInsets.only(left: 6),
                      child: _FilterChip(
                        label: categoryLabel(c),
                        icon: categoryIcon(c),
                        active: _filterCat == c,
                        color: categoryColor(c),
                        onTap: () => setState(() => _filterCat = _filterCat == c ? null : c),
                      ),
                    )),
              ],
            ),
          ),

          // Summary bar
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(color: AppColors.muted, borderRadius: BorderRadius.circular(10)),
            child: Row(
              children: [
                Text('${filtered.length} transactions', style: const TextStyle(color: AppColors.mutedForeground, fontSize: 12)),
                const Spacer(),
                Text(
                  '${totalFiltered >= 0 ? '+' : ''}\$${totalFiltered.abs().toStringAsFixed(2)}',
                  style: TextStyle(
                    color: totalFiltered >= 0 ? AppColors.success : AppColors.foreground,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),

          // List
          Expanded(
            child: filtered.isEmpty
                ? const Center(child: Text('No transactions found', style: TextStyle(color: AppColors.mutedForeground)))
                : ListView.builder(
                    itemCount: sortedDates.length,
                    itemBuilder: (_, i) {
                      final date = sortedDates[i];
                      final txs = grouped[date]!;
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 16, 16, 6),
                            child: Text(_fmtDate(date),
                                style: const TextStyle(color: AppColors.mutedForeground, fontSize: 12, fontWeight: FontWeight.w600)),
                          ),
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 16),
                            decoration: BoxDecoration(
                              color: AppColors.card,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: AppColors.border),
                            ),
                            child: Column(
                              children: txs.asMap().entries.map((e) {
                                return Column(
                                  children: [
                                    TransactionTile(
                                      transaction: e.value,
                                      onTap: () => Navigator.push(context, MaterialPageRoute(
                                        builder: (_) => TransactionDetailScreen(transaction: e.value),
                                      )),
                                    ),
                                    if (e.key < txs.length - 1) const Divider(indent: 72),
                                  ],
                                );
                              }).toList(),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool active;
  final Color? color;
  final VoidCallback onTap;
  const _FilterChip({required this.label, this.icon, required this.active, this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.primary;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: active ? c.withOpacity(0.15) : AppColors.muted,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? c : Colors.transparent),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[Icon(icon, size: 13, color: active ? c : AppColors.mutedForeground), const SizedBox(width: 4)],
            Text(label, style: TextStyle(color: active ? c : AppColors.mutedForeground, fontSize: 12, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
