import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../models/budget.dart';
import '../providers/app_provider.dart';
import '../theme.dart';
import '../widgets/spending_ring.dart';

const _uuid = Uuid();
const _budgetCategories = ['food', 'transport', 'shopping', 'health', 'subscriptions', 'utilities', 'education', 'entertainment', 'travel', 'other'];

class BudgetsScreen extends StatelessWidget {
  const BudgetsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Budgets', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_rounded),
            onPressed: () => _showAddDialog(context),
          ),
        ],
      ),
      body: app.budgets.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.pie_chart_outline_rounded, color: AppColors.mutedForeground, size: 64),
                  const SizedBox(height: 16),
                  const Text('No budgets yet', style: TextStyle(color: AppColors.foreground, fontSize: 18, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  const Text('Tap + to create your first budget', style: TextStyle(color: AppColors.mutedForeground)),
                  const SizedBox(height: 24),
                  ElevatedButton.icon(
                    onPressed: () => _showAddDialog(context),
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('Add Budget'),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: app.budgets.length,
              itemBuilder: (_, i) {
                final b = app.budgets[i];
                final spent = app.budgetSpent(b.category);
                final pct = (spent / b.limit).clamp(0.0, 1.0);
                final over = spent > b.limit;
                final color = over ? AppColors.destructive : categoryColor(b.category);

                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: over ? AppColors.destructive.withOpacity(0.5) : AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 40, height: 40,
                              decoration: BoxDecoration(
                                color: color.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(categoryIcon(b.category), color: color, size: 20),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(categoryLabel(b.category),
                                      style: const TextStyle(color: AppColors.foreground, fontWeight: FontWeight.w700, fontSize: 15)),
                                  Text(
                                    over ? 'Over budget by \$${(spent - b.limit).toStringAsFixed(2)}' : '\$${(b.limit - spent).toStringAsFixed(2)} remaining',
                                    style: TextStyle(color: over ? AppColors.destructive : AppColors.mutedForeground, fontSize: 12),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, color: AppColors.mutedForeground, size: 20),
                              onPressed: () => app.deleteBudget(b.id),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        Row(
                          children: [
                            Text('\$${spent.toStringAsFixed(2)}', style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 13)),
                            const Spacer(),
                            Text('\$${b.limit.toStringAsFixed(2)}', style: const TextStyle(color: AppColors.mutedForeground, fontSize: 13)),
                          ],
                        ),
                        const SizedBox(height: 6),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(value: pct, backgroundColor: AppColors.muted, color: color, minHeight: 8),
                        ),
                        const SizedBox(height: 4),
                        Text('${(pct * 100).toStringAsFixed(0)}% used', style: const TextStyle(color: AppColors.mutedForeground, fontSize: 11)),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _showAddDialog(BuildContext context) {
    final amountCtrl = TextEditingController();
    String selectedCat = 'food';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Add Budget', style: TextStyle(fontWeight: FontWeight.w800)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Category', style: TextStyle(color: AppColors.mutedForeground, fontSize: 13)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6, runSpacing: 6,
                  children: _budgetCategories.map((c) {
                    final active = selectedCat == c;
                    final color = categoryColor(c);
                    return GestureDetector(
                      onTap: () => setS(() => selectedCat = c),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: active ? color.withOpacity(0.15) : AppColors.muted,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: active ? color : Colors.transparent),
                        ),
                        child: Text(categoryLabel(c),
                            style: TextStyle(color: active ? color : AppColors.mutedForeground, fontSize: 12, fontWeight: FontWeight.w600)),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                const Text('Monthly Limit', style: TextStyle(color: AppColors.mutedForeground, fontSize: 13)),
                const SizedBox(height: 8),
                TextField(
                  controller: amountCtrl,
                  keyboardType: TextInputType.number,
                  autofocus: true,
                  decoration: const InputDecoration(prefixText: '\$ ', hintText: '0.00'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () {
                final limit = double.tryParse(amountCtrl.text);
                if (limit == null || limit <= 0) return;
                context.read<AppProvider>().addBudget(Budget(id: _uuid.v4(), category: selectedCat, limit: limit));
                Navigator.pop(ctx);
              },
              child: const Text('Add'),
            ),
          ],
        ),
      ),
    );
  }
}
