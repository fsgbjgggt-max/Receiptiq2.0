import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../theme.dart';
import '../widgets/spending_ring.dart';
import '../widgets/transaction_tile.dart';
import 'budgets_screen.dart';
import 'assistant_screen.dart';
import 'settings_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final spent = app.monthSpent;
    final income = app.monthIncome;
    final subs = app.monthSubscriptions;
    final ringData = app.spendingByCategory;
    final recent = app.transactions.take(5).toList();

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 0,
            title: Row(
              children: [
                const Text(
                  'ReceiptIQ',
                  style: TextStyle(
                    color: AppColors.foreground,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.smart_toy_outlined, color: AppColors.mutedForeground),
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AssistantScreen())),
                ),
                IconButton(
                  icon: const Icon(Icons.settings_outlined, color: AppColors.mutedForeground),
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
                ),
              ],
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Welcome
                Text(
                  'Hello, ${app.userName} 👋',
                  style: const TextStyle(color: AppColors.mutedForeground, fontSize: 14),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Your finances at a glance',
                  style: TextStyle(color: AppColors.foreground, fontSize: 22, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 20),

                // Spending ring + stats
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF1A1A2E), Color(0xFF16213E)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    children: [
                      Stack(
                        alignment: Alignment.center,
                        children: [
                          SpendingRing(data: ringData, size: 130, strokeWidth: 16),
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Text('Spent', style: TextStyle(color: AppColors.mutedForeground, fontSize: 11)),
                              Text(
                                '\$${spent.toStringAsFixed(0)}',
                                style: const TextStyle(color: AppColors.foreground, fontSize: 20, fontWeight: FontWeight.w800),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _StatRow(label: 'Income', value: '+\$${income.toStringAsFixed(2)}', color: AppColors.success),
                            const SizedBox(height: 12),
                            _StatRow(label: 'Expenses', value: '-\$${spent.toStringAsFixed(2)}', color: AppColors.destructive),
                            const SizedBox(height: 12),
                            _StatRow(label: 'Subscriptions', value: '\$${subs.toStringAsFixed(2)}', color: AppColors.accent),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Quick actions
                Row(
                  children: [
                    _QuickAction(
                      icon: Icons.pie_chart_rounded,
                      label: 'Budgets',
                      color: AppColors.primary,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BudgetsScreen())),
                    ),
                    const SizedBox(width: 10),
                    _QuickAction(
                      icon: Icons.smart_toy_rounded,
                      label: 'AI Assistant',
                      color: AppColors.accent,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AssistantScreen())),
                    ),
                    const SizedBox(width: 10),
                    _QuickAction(
                      icon: Icons.settings_rounded,
                      label: 'Settings',
                      color: AppColors.mutedForeground,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Budgets preview
                if (app.budgets.isNotEmpty) ...[
                  const Text('Budgets', style: TextStyle(color: AppColors.foreground, fontSize: 18, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  ...app.budgets.take(3).map((b) {
                    final s = app.budgetSpent(b.category);
                    final pct = (s / b.limit).clamp(0.0, 1.0);
                    final over = s > b.limit;
                    final color = over ? AppColors.destructive : categoryColor(b.category);
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppColors.card,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: over ? AppColors.destructive.withOpacity(0.4) : AppColors.border),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(categoryIcon(b.category), color: color, size: 16),
                                const SizedBox(width: 6),
                                Text(categoryLabel(b.category), style: const TextStyle(color: AppColors.foreground, fontWeight: FontWeight.w600, fontSize: 13)),
                                const Spacer(),
                                Text('\$${s.toStringAsFixed(0)} / \$${b.limit.toStringAsFixed(0)}',
                                    style: TextStyle(color: over ? AppColors.destructive : AppColors.mutedForeground, fontSize: 12)),
                              ],
                            ),
                            const SizedBox(height: 8),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: LinearProgressIndicator(
                                value: pct,
                                backgroundColor: AppColors.muted,
                                color: color,
                                minHeight: 6,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: 8),
                ],

                // Recent transactions
                Row(
                  children: [
                    const Text('Recent Transactions', style: TextStyle(color: AppColors.foreground, fontSize: 18, fontWeight: FontWeight.w700)),
                    const Spacer(),
                    if (app.transactions.length > 5)
                      const Text('See all', style: TextStyle(color: AppColors.primary, fontSize: 13)),
                  ],
                ),
                const SizedBox(height: 12),
                if (recent.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 32),
                    child: Center(child: Text('No transactions yet', style: TextStyle(color: AppColors.mutedForeground))),
                  )
                else
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      children: recent.asMap().entries.map((entry) {
                        final i = entry.key;
                        final tx = entry.value;
                        return Column(
                          children: [
                            TransactionTile(transaction: tx),
                            if (i < recent.length - 1) const Divider(indent: 72),
                          ],
                        );
                      }).toList(),
                    ),
                  ),
                const SizedBox(height: 32),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _StatRow({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: AppColors.mutedForeground, fontSize: 11)),
        const SizedBox(height: 2),
        Text(value, style: TextStyle(color: color, fontSize: 15, fontWeight: FontWeight.w700)),
      ],
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _QuickAction({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.2)),
          ),
          child: Column(
            children: [
              Icon(icon, color: color, size: 22),
              const SizedBox(height: 4),
              Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600), textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}
