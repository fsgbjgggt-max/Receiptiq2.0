import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../models/transaction.dart';
import '../providers/app_provider.dart';
import '../theme.dart';
import '../utils/receipt_parser.dart';
import '../widgets/spending_ring.dart';
import '../widgets/transaction_tile.dart';

const _uuid = Uuid();

const _allCategories = [
  'food', 'transport', 'shopping', 'health',
  'subscriptions', 'travel', 'utilities', 'education', 'other',
];

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  _Step _step = _Step.idle;
  String _statusMsg = '';
  ParsedReceipt? _parsed;

  final _merchantCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  final _dateCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  String _category = 'other';
  String _confidence = 'low';

  @override
  void dispose() {
    _merchantCtrl.dispose();
    _amountCtrl.dispose();
    _dateCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _pick(ImageSource source) async {
    setState(() => _step = _Step.picking);
    final picker = ImagePicker();
    final img = await picker.pickImage(source: source, imageQuality: 70);
    if (img == null) { setState(() => _step = _Step.idle); return; }

    setState(() { _step = _Step.scanning; _statusMsg = 'Initialising OCR engine…'; });

    try {
      final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
      setState(() => _statusMsg = 'Recognising text…');
      final inputImage = InputImage.fromFilePath(img.path);
      final result = await recognizer.processImage(inputImage);
      await recognizer.close();

      final text = result.text;
      setState(() => _statusMsg = 'Parsing receipt…');
      final parsed = parseReceiptText(text);

      _merchantCtrl.text = parsed.merchant;
      _amountCtrl.text = parsed.amount;
      _dateCtrl.text = parsed.date;
      _noteCtrl.text = '';
      setState(() {
        _category = parsed.category;
        _confidence = parsed.confidence;
        _step = _Step.review;
      });
    } catch (_) {
      // Fallback mock
      _merchantCtrl.text = 'Scanned Merchant';
      _amountCtrl.text = '0.00';
      _dateCtrl.text = _today();
      _noteCtrl.text = '';
      setState(() { _category = 'other'; _confidence = 'low'; _step = _Step.review; });
    }
  }

  String _today() {
    final d = DateTime.now();
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }

  void _save() {
    final amount = double.tryParse(_amountCtrl.text);
    if (amount == null || amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid amount')),
      );
      return;
    }
    context.read<AppProvider>().addTransaction(Transaction(
      id: _uuid.v4(),
      merchant: _merchantCtrl.text.trim(),
      category: _category,
      amount: -amount,
      date: _dateCtrl.text.trim(),
      note: _noteCtrl.text.trim(),
      receiptScanned: true,
    ));
    setState(() { _step = _Step.idle; });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Transaction saved!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    switch (_step) {
      case _Step.picking:
      case _Step.scanning:
        return _buildScanning();
      case _Step.review:
        return _buildReview();
      case _Step.idle:
        return _buildIdle();
    }
  }

  Widget _buildIdle() {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan Receipt', style: TextStyle(fontWeight: FontWeight.w800))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Hero
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppColors.primary.withOpacity(0.12), AppColors.accent.withOpacity(0.08)],
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.primary.withOpacity(0.3), style: BorderStyle.solid),
              ),
              child: Column(
                children: [
                  Container(
                    width: 88,
                    height: 88,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.primary, AppColors.accent],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 6))],
                    ),
                    child: const Icon(Icons.receipt_long_rounded, color: Colors.white, size: 44),
                  ),
                  const SizedBox(height: 20),
                  const Text('Scan a Receipt', style: TextStyle(color: AppColors.foreground, fontSize: 22, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  const Text(
                    'On-device OCR via Google ML Kit. Your receipt image never leaves your phone.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.mutedForeground, fontSize: 14, height: 1.5),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Buttons
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _pick(ImageSource.camera),
                icon: const Icon(Icons.camera_alt_rounded),
                label: const Text('Open Camera'),
                style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => _pick(ImageSource.gallery),
                icon: const Icon(Icons.photo_library_rounded, color: AppColors.mutedForeground),
                label: const Text('Choose from Gallery', style: TextStyle(color: AppColors.mutedForeground)),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.border),
                  padding: const EdgeInsets.symmetric(vertical: 15),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Tips
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.muted,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                children: [
                  _Tip(icon: Icons.shield_rounded, text: 'On-device OCR — image stays on your phone'),
                  _Tip(icon: Icons.cloud_off_rounded, text: 'Works fully offline after ML Kit model install'),
                  _Tip(icon: Icons.wb_sunny_rounded, text: 'Good lighting improves accuracy'),
                  _Tip(icon: Icons.crop_rounded, text: 'Keep the full receipt in frame'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScanning() {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [AppColors.primary, AppColors.accent]),
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.4), blurRadius: 30)],
                ),
                child: const CircularProgressIndicator(color: Colors.white, strokeWidth: 3),
              ),
              const SizedBox(height: 28),
              Text(
                _step == _Step.picking ? 'Opening…' : 'Scanning Receipt',
                style: const TextStyle(color: AppColors.foreground, fontSize: 22, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              Text(_statusMsg, style: const TextStyle(color: AppColors.mutedForeground, fontSize: 14), textAlign: TextAlign.center),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: AppColors.success.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Icon(Icons.shield_rounded, color: AppColors.success, size: 15),
                    SizedBox(width: 6),
                    Flexible(
                      child: Text(
                        'Processing on-device — never sent to the cloud',
                        style: TextStyle(color: AppColors.success, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildReview() {
    final confColor = _confidence == 'high' ? AppColors.success : _confidence == 'medium' ? AppColors.warning : AppColors.mutedForeground;
    final confLabel = _confidence == 'high' ? 'High confidence' : _confidence == 'medium' ? 'Review recommended' : 'Low confidence — verify';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Review & Save', style: TextStyle(fontWeight: FontWeight.w800)),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => setState(() => _step = _Step.idle),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 120),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Badges
            Row(
              children: [
                _Badge(icon: Icons.check_circle_rounded, label: 'Receipt scanned', color: AppColors.success),
                const SizedBox(width: 8),
                _Badge(icon: Icons.shield_rounded, label: confLabel, color: confColor),
              ],
            ),
            const SizedBox(height: 20),

            // Form card
            Container(
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  _FormRow(label: 'Merchant', controller: _merchantCtrl),
                  const Divider(indent: 16),
                  _FormRow(label: 'Amount', controller: _amountCtrl, keyboardType: TextInputType.number, prefix: '\$'),
                  const Divider(indent: 16),
                  _FormRow(label: 'Date', controller: _dateCtrl),
                  const Divider(indent: 16),
                  _FormRow(label: 'Note', controller: _noteCtrl),
                ],
              ),
            ),
            const SizedBox(height: 20),

            const Text('Category', style: TextStyle(color: AppColors.mutedForeground, fontSize: 13)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _allCategories.map((cat) {
                final active = _category == cat;
                final color = categoryColor(cat);
                return GestureDetector(
                  onTap: () => setState(() => _category = cat),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: active ? color.withOpacity(0.15) : AppColors.muted,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: active ? color : Colors.transparent, width: 1.5),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(categoryIcon(cat), size: 13, color: active ? color : AppColors.mutedForeground),
                        const SizedBox(width: 5),
                        Text(categoryLabel(cat), style: TextStyle(color: active ? color : AppColors.mutedForeground, fontSize: 12, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
      bottomSheet: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        decoration: const BoxDecoration(
          color: AppColors.background,
          border: Border(top: BorderSide(color: AppColors.border)),
        ),
        child: Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () => setState(() => _step = _Step.idle),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.border),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text('Discard', style: TextStyle(color: AppColors.mutedForeground)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.check_rounded),
                label: const Text('Save Transaction'),
                style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

enum _Step { idle, picking, scanning, review }

class _Tip extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Tip({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(icon, size: 15, color: AppColors.primary),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(color: AppColors.mutedForeground, fontSize: 12))),
        ],
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  const _Badge({required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 5),
          Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _FormRow extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final TextInputType? keyboardType;
  final String? prefix;
  const _FormRow({required this.label, required this.controller, this.keyboardType, this.prefix});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(label, style: const TextStyle(color: AppColors.mutedForeground, fontSize: 13)),
          ),
          if (prefix != null) Text(prefix!, style: const TextStyle(color: AppColors.mutedForeground)),
          Expanded(
            child: TextField(
              controller: controller,
              keyboardType: keyboardType,
              textAlign: TextAlign.right,
              style: const TextStyle(color: AppColors.foreground, fontSize: 15),
              decoration: const InputDecoration(
                border: InputBorder.none,
                isDense: true,
                contentPadding: EdgeInsets.zero,
                fillColor: Colors.transparent,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
