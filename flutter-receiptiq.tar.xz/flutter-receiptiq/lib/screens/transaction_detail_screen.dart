import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/transaction.dart';
import '../providers/app_provider.dart';
import '../theme.dart';
import '../widgets/transaction_tile.dart';

class TransactionDetailScreen extends StatefulWidget {
  final Transaction transaction;
  const TransactionDetailScreen({super.key, required this.transaction});

  @override
  State<TransactionDetailScreen> createState() => _TransactionDetailScreenState();
}

class _TransactionDetailScreenState extends State<TransactionDetailScreen> {
  late final _merchantCtrl = TextEditingController(text: widget.transaction.merchant);
  late final _amountCtrl = TextEditingController(text: widget.transaction.amount.abs().toStringAsFixed(2));
  late final _dateCtrl = TextEditingController(text: widget.transaction.date);
  late final _noteCtrl = TextEditingController(text: widget.transaction.note);
  bool _editing = false;

  @override
  void dispose() {
    _merchantCtrl.dispose();
    _amountCtrl.dispose();
    _dateCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final amount = double.tryParse(_amountCtrl.text) ?? 0;
    context.read<AppProvider>().updateTransaction(widget.transaction.copyWith(
      merchant: _merchantCtrl.text,
      amount: widget.transaction.amount < 0 ? -amount : amount,
      date: _dateCtrl.text,
      note: _noteCtrl.text,
    ));
    setState(() => _editing = false);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved')));
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Transaction'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: AppColors.destructive)),
          ),
        ],
      ),
    );
    if (ok == true && mounted) {
      context.read<AppProvider>().deleteTransaction(widget.transaction.id);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final tx = widget.transaction;
    final color = categoryColor(tx.category);
    final isExpense = tx.amount < 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Transaction', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          if (!_editing)
            IconButton(icon: const Icon(Icons.edit_rounded), onPressed: () => setState(() => _editing = true)),
          IconButton(icon: const Icon(Icons.delete_outline, color: AppColors.destructive), onPressed: _delete),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Amount display
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  Container(
                    width: 64, height: 64,
                    decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(18)),
                    child: Icon(categoryIcon(tx.category), color: color, size: 30),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    '${isExpense ? '-' : '+'}\$${tx.amount.abs().toStringAsFixed(2)}',
                    style: TextStyle(
                      color: isExpense ? AppColors.foreground : AppColors.success,
                      fontSize: 36,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(tx.merchant, style: const TextStyle(color: AppColors.mutedForeground, fontSize: 16)),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Fields
            Container(
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  _DetailRow('Merchant', _merchantCtrl, _editing),
                  const Divider(indent: 16),
                  _DetailRow('Amount', _amountCtrl, _editing, keyboardType: TextInputType.number, prefix: '\$'),
                  const Divider(indent: 16),
                  _DetailRow('Date', _dateCtrl, _editing),
                  const Divider(indent: 16),
                  _DetailRow('Note', _noteCtrl, _editing),
                  const Divider(indent: 16),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    child: Row(
                      children: [
                        const SizedBox(width: 80, child: Text('Category', style: TextStyle(color: AppColors.mutedForeground, fontSize: 13))),
                        Icon(categoryIcon(tx.category), color: color, size: 15),
                        const SizedBox(width: 6),
                        Text(categoryLabel(tx.category), style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 14)),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            if (_editing) ...[
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _save,
                  child: const Text('Save Changes'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final TextEditingController ctrl;
  final bool editing;
  final TextInputType? keyboardType;
  final String? prefix;
  const _DetailRow(this.label, this.ctrl, this.editing, {this.keyboardType, this.prefix});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          SizedBox(width: 80, child: Text(label, style: const TextStyle(color: AppColors.mutedForeground, fontSize: 13))),
          if (prefix != null) Text(prefix!, style: const TextStyle(color: AppColors.mutedForeground)),
          Expanded(
            child: editing
                ? TextField(
                    controller: ctrl,
                    keyboardType: keyboardType,
                    textAlign: TextAlign.right,
                    style: const TextStyle(color: AppColors.foreground, fontSize: 15),
                    decoration: const InputDecoration(border: InputBorder.none, isDense: true, contentPadding: EdgeInsets.zero, fillColor: Colors.transparent),
                  )
                : Text(ctrl.text, textAlign: TextAlign.right, style: const TextStyle(color: AppColors.foreground, fontSize: 15)),
          ),
        ],
      ),
    );
  }
}
