import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../theme.dart';
import '../widgets/spending_ring.dart';

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  int _monthOffset = 0; // 0 = current, -1 = last month, etc.

  String _monthKey(int offset) {
    final d = DateTime(DateTime.now().year, DateTime.now().month + offset);
    return '${d.year}-${d.month.toString().padLeft(2, '0')}';
  }

  String _monthLabel(int offset) {
    final d = DateTime(DateTime.now().year, DateTime.now().month + offset);
    if (offset == 0) return 'This Month';
    if (offset == -1) return 'Last Month';
    return DateFormat('MMMM yyyy').format(d);
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final mk = _monthKey(_monthOffset);
    final txs = app.transactions.where((t) => t.date.startsWith(mk) && t.amount < 0).toList();

    final spent = txs.fold(0.0, (s, t) => s + t.amount.abs());
    final income = app.transactions
        .where((t) => t.date.startsWith(mk) && t.amount > 0)
        .fold(0.0, (s, t) => s + t.amount);

    // Spending by category
    final catMap = <String, double>{};
    for (final t in txs) {
      catMap[t.category] = (catMap[t.category] ?? 0) + t.amount.abs();
    }
    final sortedCats = catMap.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    // 6-month trend bars
    final barGroups = <BarChartGroupData>[];
    double maxBarVal = 1;
    for (int i = -5; i <= 0; i++) {
      final m = _monthKey(i);
      final v = app.transactions
          .where((t) => t.date.startsWith(m) && t.amount < 0)
          .fold(0.0, (s, t) => s + t.amount.abs());
      if (v > maxBarVal) maxBarVal = v;
      barGroups.add(BarChartGroupData(
        x: i + 5,
        barRods: [
          BarChartRodData(
            toY: v,
            color: i == _monthOffset + 5 ? AppColors.primary : AppColors.primary.withOpacity(0.35),
            width: 20,
            borderRadius: BorderRadius.circular(6),
          ),
        ],
      ));
    }

    // Subscriptions
    final subs = app.transactions
        .where((t) => t.isSubscription && t.date.startsWith(mk))
        .toList();
    final subTotal = subs.fold(0.0, (s, t) => s + t.amount.abs());

    return Scaffold(
      appBar: AppBar(title: const Text('Analytics', style: TextStyle(fontWeight: FontWeight.w800))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Month selector
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.chevron_left_rounded, color: AppColors.foreground),
                  onPressed: _monthOffset > -5 ? () => setState(() => _monthOffset--) : null,
                ),
                Expanded(
                  child: Text(
                    _monthLabel(_monthOffset),
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppColors.foreground, fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.chevron_right_rounded, color: AppColors.foreground),
                  onPressed: _monthOffset < 0 ? () => setState(() => _monthOffset++) : null,
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Summary row
            Row(
              children: [
                _SummaryCard(label: 'Total Spent', value: '-\$${spent.toStringAsFixed(2)}', color: AppColors.destructive),
                const SizedBox(width: 10),
                _SummaryCard(label: 'Total Income', value: '+\$${income.toStringAsFixed(2)}', color: AppColors.success),
              ],
            ),
            const SizedBox(height: 20),

            // 6-month trend
            const Text('6-Month Trend', style: TextStyle(color: AppColors.foreground, fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Container(
              height: 180,
              padding: const EdgeInsets.fromLTRB(0, 16, 16, 0),
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: BarChart(
                BarChartData(
                  barGroups: barGroups,
                  gridData: const FlGridData(show: false),
                  borderData: FlBorderData(show: false),
                  maxY: maxBarVal * 1.3,
                  titlesData: FlTitlesData(
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (v, _) {
                          final offset = v.toInt() - 5;
                          final d = DateTime(DateTime.now().year, DateTime.now().month + offset);
                          return Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(DateFormat('MMM').format(d),
                                style: const TextStyle(color: AppColors.mutedForeground, fontSize: 10)),
                          );
                        },
                      ),
                    ),
                    leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Category breakdown
            if (sortedCats.isNotEmpty) ...[
              const Text('Spending by Category', style: TextStyle(color: AppColors.foreground, fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              ...sortedCats.map((e) {
                final pct = spent > 0 ? e.value / spent : 0.0;
                final color = categoryColor(e.key);
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(categoryIcon(e.key), color: color, size: 15),
                            const SizedBox(width: 6),
                            Text(categoryLabel(e.key), style: const TextStyle(color: AppColors.foreground, fontWeight: FontWeight.w600, fontSize: 13)),
                            const Spacer(),
                            Text('\$${e.value.toStringAsFixed(2)}', style: const TextStyle(color: AppColors.foreground, fontWeight: FontWeight.w700, fontSize: 13)),
                            const SizedBox(width: 8),
                            Text('${(pct * 100).toStringAsFixed(0)}%', style: const TextStyle(color: AppColors.mutedForeground, fontSize: 12)),
                          ],
                        ),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(value: pct, backgroundColor: AppColors.muted, color: color, minHeight: 6),
                        ),
                      ],
                    ),
                  ),
                );
              }),
              const SizedBox(height: 16),
            ],

            // Subscriptions
            if (subs.isNotEmpty) ...[
              Row(
                children: [
                  const Text('Subscriptions', style: TextStyle(color: AppColors.foreground, fontSize: 16, fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Text('\$${subTotal.toStringAsFixed(2)}/mo',
                      style: const TextStyle(color: AppColors.accent, fontWeight: FontWeight.w700, fontSize: 14)),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  children: subs.asMap().entries.map((entry) {
                    final t = entry.value;
                    return Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          child: Row(
                            children: [
                              Icon(categoryIcon(t.category), color: AppColors.accent, size: 16),
                              const SizedBox(width: 10),
                              Expanded(child: Text(t.merchant, style: const TextStyle(color: AppColors.foreground, fontWeight: FontWeight.w600))),
                              Text('-\$${t.amount.abs().toStringAsFixed(2)}', style: const TextStyle(color: AppColors.foreground, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                        if (entry.key < subs.length - 1) const Divider(indent: 42),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ],
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _SummaryCard({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(color: AppColors.mutedForeground, fontSize: 12)),
            const SizedBox(height: 6),
            Text(value, style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }
}
