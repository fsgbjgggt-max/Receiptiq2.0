import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../theme.dart';

class _Message {
  final String text;
  final bool isUser;
  _Message(this.text, {required this.isUser});
}

class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});

  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  final _messages = <_Message>[];
  bool _typing = false;

  @override
  void initState() {
    super.initState();
    _messages.add(_Message(
      "Hi! I'm your ReceiptIQ assistant. Ask me about your spending, budgets, or get financial tips.",
      isUser: false,
    ));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    _ctrl.clear();
    setState(() => _messages.add(_Message(text, isUser: true)));
    await Future.delayed(const Duration(milliseconds: 100));
    _scrollToBottom();

    setState(() => _typing = true);
    await Future.delayed(const Duration(milliseconds: 800));

    final app = context.read<AppProvider>();
    final reply = _generateReply(text, app);

    setState(() {
      _typing = false;
      _messages.add(_Message(reply, isUser: false));
    });
    await Future.delayed(const Duration(milliseconds: 50));
    _scrollToBottom();
  }

  void _scrollToBottom() {
    if (_scroll.hasClients) {
      _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    }
  }

  String _generateReply(String input, AppProvider app) {
    final q = input.toLowerCase();
    final spent = app.monthSpent;
    final income = app.monthIncome;
    final subs = app.monthSubscriptions;
    final catMap = app.spendingByCategory;
    final topCat = catMap.entries.isEmpty ? null : (catMap.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).first;

    if (q.contains('hello') || q.contains('hi') || q.contains('hey')) {
      return "Hello! I can help you understand your spending patterns and give financial advice. What would you like to know?";
    }
    if (q.contains('spend') || q.contains('spent') || q.contains('total')) {
      return "This month you've spent \$${spent.toStringAsFixed(2)}${income > 0 ? ' against \$${income.toStringAsFixed(2)} income. Your savings rate is ${((1 - spent / income) * 100).clamp(0, 100).toStringAsFixed(0)}%.' : '.'}";
    }
    if (q.contains('subscri')) {
      if (subs == 0) return "No subscriptions found this month.";
      return "You have \$${subs.toStringAsFixed(2)}/month in subscriptions. That's \$${(subs * 12).toStringAsFixed(2)}/year. ${subs > 50 ? 'Consider reviewing which ones you actually use.' : 'Looks reasonable!'}";
    }
    if (q.contains('budget')) {
      if (app.budgets.isEmpty) return "You haven't set any budgets yet. Go to the Budgets section to set spending limits by category.";
      final overBudget = app.budgets.where((b) => app.budgetSpent(b.category) > b.limit).toList();
      if (overBudget.isEmpty) return "Great news — you're within budget in all categories this month! Keep it up.";
      return "You're over budget in: ${overBudget.map((b) => b.category).join(', ')}. Consider adjusting your spending or increasing those limits.";
    }
    if (q.contains('top') || q.contains('most') || q.contains('biggest') || q.contains('category')) {
      if (topCat == null) return "No spending data yet for this month.";
      return "Your biggest spending category this month is ${topCat.key} at \$${topCat.value.toStringAsFixed(2)} (${((topCat.value / spent) * 100).toStringAsFixed(0)}% of total spending).";
    }
    if (q.contains('save') || q.contains('saving') || q.contains('tip')) {
      final tips = [
        "Try the 50/30/20 rule: 50% needs, 30% wants, 20% savings.",
        "Reviewing your subscriptions monthly can save you \$200-500/year on average.",
        "Cooking at home just 3 more times per week can save \$200-400/month.",
        "Automating savings to a separate account the day you get paid prevents lifestyle inflation.",
        "Tracking every expense (like you're doing now!) is the #1 habit of people who achieve financial goals.",
      ];
      return tips[(tips.length * (DateTime.now().millisecond / 1000)).floor() % tips.length];
    }
    if (q.contains('income') || q.contains('earn')) {
      if (income == 0) return "No income recorded this month. Add income transactions to see your savings rate.";
      return "You've earned \$${income.toStringAsFixed(2)} this month and spent \$${spent.toStringAsFixed(2)}, leaving \$${(income - spent).toStringAsFixed(2)}.";
    }
    if (q.contains('transaction') || q.contains('recent')) {
      final recent = app.transactions.take(3);
      if (recent.isEmpty) return "No transactions yet.";
      return "Your 3 most recent transactions:\n${recent.map((t) => '• ${t.merchant}: \$${t.amount.abs().toStringAsFixed(2)}').join('\n')}";
    }

    return "I can help with spending summaries, budget tracking, subscription analysis, and savings tips. Try asking: 'How much did I spend?', 'Am I over budget?', or 'Give me a savings tip'.";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppColors.primary, AppColors.accent]),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.smart_toy_rounded, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 10),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('AI Assistant', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                Text('On-device · Private', style: TextStyle(color: AppColors.success, fontSize: 10)),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scroll,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length + (_typing ? 1 : 0),
              itemBuilder: (_, i) {
                if (_typing && i == _messages.length) {
                  return _TypingBubble();
                }
                final m = _messages[i];
                return _MessageBubble(message: m);
              },
            ),
          ),
          // Suggestions
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                'How much did I spend?',
                'Am I over budget?',
                'My subscriptions',
                'Give me a tip',
              ].map((s) => Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ActionChip(
                  label: Text(s, style: const TextStyle(color: AppColors.primary, fontSize: 12)),
                  backgroundColor: AppColors.primary.withOpacity(0.1),
                  side: const BorderSide(color: AppColors.primary, width: 0.5),
                  onPressed: () { _ctrl.text = s; _send(); },
                ),
              )).toList(),
            ),
          ),
          const SizedBox(height: 8),
          // Input
          Container(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            decoration: const BoxDecoration(
              border: Border(top: BorderSide(color: AppColors.border)),
              color: AppColors.background,
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    style: const TextStyle(color: AppColors.foreground),
                    decoration: const InputDecoration(hintText: 'Ask about your spending…'),
                    onSubmitted: (_) => _send(),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 46, height: 46,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [AppColors.primary, AppColors.accent]),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                    onPressed: _send,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final _Message message;
  const _MessageBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    final isUser = message.isUser;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          gradient: isUser
              ? const LinearGradient(colors: [AppColors.primary, AppColors.accent])
              : null,
          color: isUser ? null : AppColors.card,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(isUser ? 18 : 4),
            bottomRight: Radius.circular(isUser ? 4 : 18),
          ),
          border: isUser ? null : Border.all(color: AppColors.border),
        ),
        child: Text(
          message.text,
          style: TextStyle(
            color: isUser ? Colors.white : AppColors.foreground,
            fontSize: 14,
            height: 1.5,
          ),
        ),
      ),
    );
  }
}

class _TypingBubble extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(18),
            topRight: Radius.circular(18),
            bottomRight: Radius.circular(18),
            bottomLeft: Radius.circular(4),
          ),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) => Container(
            width: 7, height: 7,
            margin: const EdgeInsets.symmetric(horizontal: 2),
            decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.6 + i * 0.2), shape: BoxShape.circle),
          )),
        ),
      ),
    );
  }
}
