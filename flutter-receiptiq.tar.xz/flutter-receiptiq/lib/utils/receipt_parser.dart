class ParsedReceipt {
  final String merchant;
  final String amount;
  final String date;
  final String category;
  final String confidence; // 'high' | 'medium' | 'low'

  const ParsedReceipt({
    required this.merchant,
    required this.amount,
    required this.date,
    required this.category,
    required this.confidence,
  });
}

String _today() {
  final d = DateTime.now();
  return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}

String _parseDate(String text) {
  final patterns = [
    RegExp(r'\b(\d{1,2})[/\-](\d{1,2})[/\-](\d{4})\b'),
    RegExp(r'\b(\d{4})[/\-](\d{1,2})[/\-](\d{1,2})\b'),
    RegExp(r'\b(\d{1,2})[/\-](\d{1,2})[/\-](\d{2})\b'),
  ];

  for (final re in patterns) {
    final m = re.firstMatch(text);
    if (m != null) {
      final a = m.group(1)!, b = m.group(2)!, c = m.group(3)!;
      if (c.length == 4) {
        return '$c-${a.padLeft(2, '0')}-${b.padLeft(2, '0')}';
      } else if (a.length == 4) {
        return '$a-${b.padLeft(2, '0')}-${c.padLeft(2, '0')}';
      } else {
        return '20$c-${a.padLeft(2, '0')}-${b.padLeft(2, '0')}';
      }
    }
  }
  return _today();
}

String _parseAmount(String text) {
  final totalRe = RegExp(
    r'(?:GRAND\s+TOTAL|TOTAL\s+DUE|AMOUNT\s+DUE|BALANCE\s+DUE|TOTAL)[:\s]*\$?\s*(\d{1,5}[.,]\d{2})',
    caseSensitive: false,
  );
  final tm = totalRe.firstMatch(text);
  if (tm != null) return tm.group(1)!.replaceAll(',', '.');

  final amounts = <double>[];
  for (final m in RegExp(r'\$\s*(\d{1,5}[.,]\d{2})\b').allMatches(text)) {
    amounts.add(double.tryParse(m.group(1)!.replaceAll(',', '.')) ?? 0);
  }
  for (final m in RegExp(r'\b(\d{1,3}(?:,\d{3})*\.\d{2})\b').allMatches(text)) {
    final v = double.tryParse(m.group(1)!.replaceAll(',', '')) ?? 0;
    if (v > 0.5 && v < 10000) amounts.add(v);
  }
  if (amounts.isEmpty) return '';
  amounts.sort();
  return amounts.last.toStringAsFixed(2);
}

String _parseMerchant(String text) {
  final lines = text
      .split('\n')
      .map((l) => l.trim())
      .where((l) => l.length >= 3 && l.length <= 50 && RegExp(r'[a-zA-Z]{2,}').hasMatch(l))
      .toList();

  for (final line in lines.take(4)) {
    final cleaned = line.replaceAll(RegExp(r'[^a-zA-Z0-9\s&\''.,-]'), '').trim();
    if (cleaned.length >= 3 && !RegExp(r'^[\d\s]+$').hasMatch(cleaned) && !cleaned.contains('www')) {
      return cleaned;
    }
  }
  return lines.isNotEmpty ? lines.first : 'Unknown Merchant';
}

const _categoryKeywords = <String, List<String>>{
  'food': ['restaurant', 'cafe', 'coffee', 'starbucks', 'diner', 'pizza', 'burger', 'sushi', 'grill', 'kitchen', 'bakery', 'deli', 'mcdonalds', 'subway', 'chipotle', 'grocery', 'supermarket', 'whole foods', 'trader joe'],
  'transport': ['gas station', 'shell', 'chevron', 'bp ', 'exxon', 'mobil', 'fuel', 'petrol', 'uber', 'lyft', 'taxi', 'transit', 'metro', 'bus', 'amtrak', 'parking'],
  'subscriptions': ['netflix', 'spotify', 'hulu', 'disney', 'apple one', 'adobe', 'google one', 'amazon prime', 'subscription'],
  'utilities': ['at&t', 'verizon', 'comcast', 'xfinity', 'spectrum', 't-mobile', 'electric', 'utility', 'water bill', 'internet'],
  'health': ['cvs', 'walgreens', 'rite aid', 'pharmacy', 'medical', 'clinic', 'hospital', 'dental', 'urgent care', 'doctor', 'gym', 'equinox', 'planet fitness'],
  'travel': ['hotel', 'airbnb', 'hilton', 'marriott', 'hyatt', 'united airlines', 'delta', 'southwest', 'american airlines', 'flight'],
  'shopping': ['amazon', 'target', 'walmart', 'best buy', 'home depot', 'costco', 'ikea', 'nordstrom', 'macy', 'gap ', 'zara', 'nike', 'adidas'],
  'education': ['university', 'college', 'coursera', 'udemy', 'school', 'tuition', 'textbook'],
};

String _inferCategory(String text, String merchant) {
  final combined = '${text.toLowerCase()} ${merchant.toLowerCase()}';
  for (final entry in _categoryKeywords.entries) {
    for (final kw in entry.value) {
      if (combined.contains(kw)) return entry.key;
    }
  }
  return 'other';
}

ParsedReceipt parseReceiptText(String rawText) {
  final merchant = _parseMerchant(rawText);
  final amount = _parseAmount(rawText);
  final date = _parseDate(rawText);
  final category = _inferCategory(rawText, merchant);

  final hasMerchant = merchant.length >= 3;
  final hasAmount = amount.isNotEmpty;
  final confidence = hasMerchant && hasAmount ? 'high' : hasMerchant || hasAmount ? 'medium' : 'low';

  return ParsedReceipt(
    merchant: merchant,
    amount: amount,
    date: date,
    category: category,
    confidence: confidence,
  );
}
