class Budget {
  final String id;
  final String category;
  final double limit;

  const Budget({required this.id, required this.category, required this.limit});

  Budget copyWith({String? category, double? limit}) =>
      Budget(id: id, category: category ?? this.category, limit: limit ?? this.limit);

  Map<String, dynamic> toJson() => {'id': id, 'category': category, 'limit': limit};

  factory Budget.fromJson(Map<String, dynamic> j) => Budget(
        id: j['id'] as String,
        category: j['category'] as String,
        limit: (j['limit'] as num).toDouble(),
      );
}
