class Transaction {
  final String id;
  final String merchant;
  final String category;
  final double amount;
  final String date;
  final String note;
  final bool receiptScanned;
  final bool isSubscription;

  const Transaction({
    required this.id,
    required this.merchant,
    required this.category,
    required this.amount,
    required this.date,
    this.note = '',
    this.receiptScanned = false,
    this.isSubscription = false,
  });

  Transaction copyWith({
    String? merchant,
    String? category,
    double? amount,
    String? date,
    String? note,
    bool? receiptScanned,
    bool? isSubscription,
  }) =>
      Transaction(
        id: id,
        merchant: merchant ?? this.merchant,
        category: category ?? this.category,
        amount: amount ?? this.amount,
        date: date ?? this.date,
        note: note ?? this.note,
        receiptScanned: receiptScanned ?? this.receiptScanned,
        isSubscription: isSubscription ?? this.isSubscription,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'merchant': merchant,
        'category': category,
        'amount': amount,
        'date': date,
        'note': note,
        'receiptScanned': receiptScanned,
        'isSubscription': isSubscription,
      };

  factory Transaction.fromJson(Map<String, dynamic> j) => Transaction(
        id: j['id'] as String,
        merchant: j['merchant'] as String,
        category: j['category'] as String,
        amount: (j['amount'] as num).toDouble(),
        date: j['date'] as String,
        note: (j['note'] as String?) ?? '',
        receiptScanned: (j['receiptScanned'] as bool?) ?? false,
        isSubscription: (j['isSubscription'] as bool?) ?? false,
      );
}
